%% ASSIGNMENT TWO %%
%% FOR ASSIGNMENT ONE PLOTTING PLOTTS %%
%% IMPORTATION OF THE TABLE FROM EXCEL SHEET %%
PTI=readtable("C:\Users\Daniel\Desktop\ASSIGNMENT TWO\group A.xlsx");
%% LINEPLOTTING %%
% fig1=figure("Name",'lineplot');
% x=PTI.AGE;
% y=sin(x);
% plot(x,y);
% xlabel('x');
% ylabel('sin(x)');
% title('A line plot for heights of PTI students');
% saveas(fig1,'C:\Users\Daniel\Desktop\ASSIGNMENT TWO\LINEPLOT.png');
% grid on;
% %% SCATTER PLOTTING %%
% fig2=figure("name",'scatterplot');
% x=PTI.HEIGHT_feet_;
% y=PTI.AGE;
% scatter(x, y);
% xlabel('x');
% ylabel('y');
% title('scatterplot');
% saveas(fig2,'C:\Users\Daniel\Desktop\ASSIGNMENT TWO\SCATTER.png');
% grid on;
% %% ARE PLOTTING %%
% fig3=figure("Name",'areplot');
% x=PTI.AGE;
% y=sin(x);
% plot(x,y);
% xlabel('x');
% ylabel('sin(x)');
% title('Areplot');
% saveas(fig3,"C:\Users\Daniel\Desktop\ASSIGNMENT TWO\ARE.png");
% Grid on;
%% Bar plotting %%
% bar(PTI.AGE,'r');
% xlabel('NAMES','Color','g');
% ylabel('AGE','Color','r');
% xticklabels(PTI.NAMES);
% xtickangle(45);
% set(gca,'FontSize',8);
% title('A BAR GRAPH SHOWING THE AGES OF PTI STUDENTS');
% shg;
%% HISTOGRAM %%
marks=readtable("C:\Users\Daniel\Desktop\ASSIGNMENT TWO\MARKS.xlsx");
% score=marks.ENGINEERINGMATHS2MARKS;
% histogram(score,'FaceColor','r');
% xlabel('ENGINEERINGMATHS','Color','b','FontSize',15);
% ylabel('FREGUENCY','Color','g','FontSize',15);
% title('HISTOGRAM','Color','k','FontSize',15);
%% HISTOGRAM_2_%%
% score=marks.MECH2MARKS;
% histogram(score,'BinWidth',10);
% xlabel('ENGINEERINGMECHANICS','Color','b','FontSize',15);
% ylabel('FREGUENCY','Color','g','FontSize',15);
% title('HISTOGRAM','Color','k','FontSize',15);
% shg;
%% histogram_3_%%
% score=marks.PRODTECHNOLOGY;
% histogram(score,'BinWidth',10,'FaceColor','g');
% xlabel('PRODUCTION TECHNOLOGY','Color','b','FontSize',15);
% ylabel('FREGUENCY','Color','r','FontSize',15);
% title('HISTOGRAM','Color','k','FontSize',15);
% shg;
%% HISTOGRAM_4 %%
% score=marks.SPINNINGTECHNOLOGY;
% histogram(score,'BinWidth',10,'FaceColor','m');
% xlabel('SPINNING TECHNOLOGY','Color','b','FontSize',15);
% ylabel('FREGUENCY','Color','r','FontSize',15);
% title('HISTOGRAM','Color','k','FontSize',15);
% shg;
%% HISTOGRAM_5 %%
% score=marks.ELECTRICALTECH;
% histogram(score,'BinWidth',10,'FaceColor','c');
% xlabel('ELECTRICAL TECHNOLOGY','Color','b','FontSize',15);
% ylabel('FREGUENCY','Color','r','FontSize',15);
% title('HISTOGRAM','Color','k','FontSize',15);
% shg;
%% HISTOGRAM_6 %%
% score=marks.ORGANICCHEM;
% histogram(score,'BinWidth',10,'FaceColor','k');
% xlabel('ORGANIC CHEMISTRY','Color','b','FontSize',15);
% ylabel('FREGUENCY','Color','r','FontSize',15);
% title('HISTOGRAM','Color','k','FontSize',15);
% shg;
%% PIE CHART %%
% ages=PTI.AGE;
% edges=[20,23,26,29,32,35];
% ageLabels={'20-22 yrs','23-25 yrs','26-28 yrs','29-31 yrs','32-34 yrs'};
% ageCounts=histcounts(ages,edges);
% pie(ageCounts, ageLabels);
% title('A PIE CHART SHOWING AGE DISTRIBUTION OF PTI STUDENTS');
%% PIE CHAT %%
gender = PTI.GENDER;
[counts,groups] =groupcounts (gender);
pie(counts,groups);
title('A PIE CHART SHOWING THE STATUS OF PTI STUDENTS');
%% PARETO CHART%%
marks = marks.ENGINEERINGMATHS2MARKS;
edges = [0,50,60,70,80,100];
[counts,~]= histcounts(marks,edges);
markLabels={'0-49','50-59','60-69','70-79','80-100'};
pareto(counts,markLabels);
title('PARETO CHART SHOWING ENGINEERING MATHS PERFORMANCE')
xlabel('Mark');
ylabel('No of Students');
shg;
%% LOGARITHMIC GRAPH%%
marks=readtable("C:\Users\Daniel\Desktop\ASSIGNMENT TWO\MARKS.xlsx");
loglog(marks.GPA,marks.ENGINEERINGMATHS2MARKS);
title('LOGARITHMIC PLOT');
xlabel('GPA(Log Scale)');
ylabel('Engineering Maths(Log Scale)');
%% box plot%%
boxplot(marks.ENGINEERINGMATHS2MARKS);
title('BOX PLOT OF ENGINEERING MATHSMARKS');
ylabel('Marks');
grid on;
%% AREA GRAPH %%
sortedMarks=sort(marks.ENGINEERINGMATHS2MARKS);
area(sortedMarks,'FaceColor',[0.3,0.6,0.9],'EdgeColor','k','LineWidth',1.2);
title('AREA UNDER GRAPH');
ylabel('Marks');
grid on;
%% STEP PLOT%%
sortedMarks=(marks.MECH2MARKS);
stairs(sortedMarks,'LineWidth',1.5,'Color','b');
title('STEP PLOT FOR ENGINEERING MECHANICS');
xlabel('students');
ylabel('Marks');
grid on;





